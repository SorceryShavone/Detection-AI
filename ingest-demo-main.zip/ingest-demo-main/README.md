# ingest-demo
Image ingestion demo using GPT4-V, Python, Streamlit, and CosmosDB PostgreSQL
