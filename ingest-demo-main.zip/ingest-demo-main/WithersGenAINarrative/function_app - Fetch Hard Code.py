import logging
import azure.functions as func
import os
import requests
import base64
from io import BytesIO
from PIL import Image

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="WithersGenAINarrative")
def WithersGenAINarrative(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        # Read image from request body
        image_data = req.get_body()
        if not image_data:
            return func.HttpResponse("Please pass an image in the request body", status_code=400)

        # Convert image to base64 string
        image = Image.open(BytesIO(image_data))
        buffered = BytesIO()
        image.save(buffered, format="JPEG")
        encoded_image = base64.b64encode(buffered.getvalue()).decode('ascii')

        # Azure OpenAI GPT model details
        #api_key = os.environ["OPENAI_KEY"]
        #gpt4_endpoint = os.environ["OPENAI_ENDPOINT"]
        #api_key = "<YOUR KEY>"
        #gpt4_endpoint = "<YOUR ENDPOINT>"
        api_key = "<WITHERS KEY>"
        gpt4_endpoint = "https://witherspocaoai.openai.azure.com/openai/deployments/withersgpt4turbo/chat/completions?api-version=2024-05-01-preview"

        # Create headers for the request
        headers = {
            "Content-Type": "application/json",
            "api-key": api_key,
        }

        # Create the payload for the request
        payload = {
            "messages": [
                {
                    "role": "system",
                    "content": [
                        {
                            "type": "text",
                            "text": "You are a helpful assistant that looks at images and describes the image(s) in as much detail as possible. Don't use any apostrophe characters (like this ') in your response or possessive nouns (like the man's) in your response."
                        }
                    ]
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "Describe the scene in this picture with as much detail as possible. Don't use any apostrophe characters (like this ') in your response or possessive nouns (like the man's) in your response. Review your output, and if there are any apostrophe characters (like this ') replace them with double quotes."
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{encoded_image}"
                            }
                        }
                    ]
                }
            ],
            "temperature": 0.7,
            "top_p": 0.95,
            "max_tokens": 2000
        }

        # Send request to GPT-4 endpoint
        response = requests.post(gpt4_endpoint, headers=headers, json=payload)
        response.raise_for_status()  # Will raise an HTTPError if the HTTP request returned an unsuccessful status code
        
        # Extract the narrative from the response
        narrative = response.json()['choices'][0]['message']['content']
        return func.HttpResponse(narrative, status_code=200)

    except Exception as e:
        logging.error(f"Exception occurred: {e}")
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
