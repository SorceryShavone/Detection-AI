import logging
import azure.functions as func
import openai
import os
import json
from PIL import Image
from io import BytesIO

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="WithersGenAINarrative")
def WithersGenAINarrative(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        # Read image from request body
        image_data = req.get_body()
        if not image_data:
            return func.HttpResponse("Please pass an image in the request body", status_code=400)
        
        # Convert image to base64 string
        image = Image.open(BytesIO(image_data))
        buffered = BytesIO()
        image.save(buffered, format="JPEG")
        image_base64 = base64.b64encode(buffered.getvalue()).decode("utf-8")

        # Create the GPT-4 prompt
        messages = [
            {"role": "system", "content": "You are a helpful assistant that looks at images and describes the image(s) in as much detail as possible. Don't use any apostrophe characters (like this ') in your response or possessive nouns (like the man's) in your response."},
            {"role": "user", "content": "Describe the scene in this picture with as much detail as possible. Don't use any apostrophe characters (like this ') in your response or possessive nouns (like the man's) in your response. Review your output, and if there are any apostrophe characters (like this ') replace them with double quotes."},
            {"role": "user", "content": f"data:image/jpeg;base64,{image_base64}"}
        ]

        # Azure OpenAI GPT model details
        azure_openai_endpoint = "<YOUR ENDPOINT>"
        api_key = "<YOUR KEY>"
        model_deployment_name = "<YOUR MODEL>"
        api_version = "2024-05-01-preview"
        
        # Call GPT-4
        openai.api_key = api_key
        openai.api_base = azure_openai_endpoint
        response = openai.ChatCompletion.create(
            model=model_deployment_name,
            messages=messages,
            max_tokens=2000
        )

        # Extract the narrative from the response
        narrative = response['choices'][0]['message']['content']
        return func.HttpResponse(narrative, status_code=200)

    except Exception as e:
        logging.error(f"Exception occurred: {e}")
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
