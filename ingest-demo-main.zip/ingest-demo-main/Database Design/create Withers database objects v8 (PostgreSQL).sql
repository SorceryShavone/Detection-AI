--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Ubuntu 16.3-1.pgdg20.04+1)
-- Dumped by pg_dump version 16.0

-- Started on 2024-08-08 10:25:25

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 323 (class 1259 OID 19780)
-- Name: ArtistImage; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public."ArtistImage" (
    artist_id integer NOT NULL,
    file_id integer NOT NULL,
    is_owner boolean NOT NULL
);


ALTER TABLE public."ArtistImage" OWNER TO citus;

--
-- TOC entry 324 (class 1259 OID 19783)
-- Name: ArtistVideo; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public."ArtistVideo" (
    artist_id integer NOT NULL,
    video_id integer NOT NULL,
    is_owner boolean NOT NULL
);


ALTER TABLE public."ArtistVideo" OWNER TO citus;

--
-- TOC entry 345 (class 1259 OID 24626)
-- Name: TestTable; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public."TestTable" (
    "TestId" integer NOT NULL,
    "TestName" character varying(255)
);


ALTER TABLE public."TestTable" OWNER TO citus;

--
-- TOC entry 344 (class 1259 OID 24625)
-- Name: TestTable_TestId_seq; Type: SEQUENCE; Schema: public; Owner: citus
--

CREATE SEQUENCE public."TestTable_TestId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TestTable_TestId_seq" OWNER TO citus;

--
-- TOC entry 5686 (class 0 OID 0)
-- Dependencies: 344
-- Name: TestTable_TestId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: citus
--

ALTER SEQUENCE public."TestTable_TestId_seq" OWNED BY public."TestTable"."TestId";


--
-- TOC entry 325 (class 1259 OID 19786)
-- Name: UserAssocType; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public."UserAssocType" (
    user_assoc_type_id integer NOT NULL,
    user_assoc_type_desc character varying(255) NOT NULL
);


ALTER TABLE public."UserAssocType" OWNER TO citus;

--
-- TOC entry 346 (class 1259 OID 24632)
-- Name: UserImage; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public."UserImage" (
    user_id integer NOT NULL,
    file_id integer NOT NULL,
    user_assoc_type_id integer NOT NULL,
    approval_step_no integer,
    approval_date date
);


ALTER TABLE public."UserImage" OWNER TO citus;

--
-- TOC entry 343 (class 1259 OID 24618)
-- Name: UserRoles; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public."UserRoles" (
    user_id integer NOT NULL,
    user_assoc_type_id integer NOT NULL
);


ALTER TABLE public."UserRoles" OWNER TO citus;

--
-- TOC entry 326 (class 1259 OID 19792)
-- Name: UserVideo; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public."UserVideo" (
    user_id integer NOT NULL,
    video_id integer NOT NULL,
    user_assoc_type_id integer NOT NULL,
    approval_step_no integer,
    approval_date date
);


ALTER TABLE public."UserVideo" OWNER TO citus;

--
-- TOC entry 327 (class 1259 OID 19795)
-- Name: Videos; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public."Videos" (
    video_id integer NOT NULL,
    video_title character varying(255) NOT NULL,
    video_short_ character varying(255),
    storage_url character varying(1024) NOT NULL,
    playtime_seconds integer
);


ALTER TABLE public."Videos" OWNER TO citus;

--
-- TOC entry 328 (class 1259 OID 19800)
-- Name: artists; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public.artists (
    artist_id integer NOT NULL,
    name character varying(255)
);


ALTER TABLE public.artists OWNER TO citus;

--
-- TOC entry 329 (class 1259 OID 19803)
-- Name: artists_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: citus
--

CREATE SEQUENCE public.artists_artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.artists_artist_id_seq OWNER TO citus;

--
-- TOC entry 5687 (class 0 OID 0)
-- Dependencies: 329
-- Name: artists_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: citus
--

ALTER SEQUENCE public.artists_artist_id_seq OWNED BY public.artists.artist_id;


--
-- TOC entry 330 (class 1259 OID 19804)
-- Name: derivatives; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public.derivatives (
    derivative_id integer NOT NULL,
    file_id integer,
    derivative_type character varying(50),
    derivative_confid_score numeric(2,2)
);


ALTER TABLE public.derivatives OWNER TO citus;

--
-- TOC entry 331 (class 1259 OID 19807)
-- Name: derivatives_derivative_id_seq; Type: SEQUENCE; Schema: public; Owner: citus
--

CREATE SEQUENCE public.derivatives_derivative_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.derivatives_derivative_id_seq OWNER TO citus;

--
-- TOC entry 5688 (class 0 OID 0)
-- Dependencies: 331
-- Name: derivatives_derivative_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: citus
--

ALTER SEQUENCE public.derivatives_derivative_id_seq OWNED BY public.derivatives.derivative_id;


--
-- TOC entry 332 (class 1259 OID 19808)
-- Name: devices; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public.devices (
    device_id integer NOT NULL,
    manufacturer character varying(255),
    model_name character varying(255)
);


ALTER TABLE public.devices OWNER TO citus;

--
-- TOC entry 333 (class 1259 OID 19813)
-- Name: devices_device_id_seq; Type: SEQUENCE; Schema: public; Owner: citus
--

CREATE SEQUENCE public.devices_device_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.devices_device_id_seq OWNER TO citus;

--
-- TOC entry 5689 (class 0 OID 0)
-- Dependencies: 333
-- Name: devices_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: citus
--

ALTER SEQUENCE public.devices_device_id_seq OWNED BY public.devices.device_id;


--
-- TOC entry 334 (class 1259 OID 19814)
-- Name: images; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public.images (
    file_id integer NOT NULL,
    title character varying(255),
    filename_short character varying(255),
    alt_url character varying(1024),
    description text,
    date_captured timestamp with time zone,
    location character varying(255),
    mime_type character varying(50),
    file_size bigint,
    width integer,
    height integer,
    md5 character varying(32),
    device_id integer,
    uploaded_by integer,
    accession_id integer,
    aperature character varying(255),
    book_page_revolution integer,
    box_number integer,
    box_envelope character varying(255),
    caption character varying(1024),
    caw_batch character varying(255),
    color_profile character varying(255),
    creative_software character varying(255),
    envolope character varying(255),
    ew_collection_subject character varying(255),
    flash_used_ind boolean,
    format character varying(255),
    hyperfocal_distance character varying(255),
    lens_type character varying(255),
    nft_ind boolean,
    shutter_speed double precision,
    signature boolean,
    suggested_image_data text,
    text_in_image text,
    withers_notes text,
    copyright_hold_ind boolean,
    approval_status_ind boolean
);


ALTER TABLE public.images OWNER TO citus;

--
-- TOC entry 335 (class 1259 OID 19819)
-- Name: images_file_id_seq; Type: SEQUENCE; Schema: public; Owner: citus
--

CREATE SEQUENCE public.images_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.images_file_id_seq OWNER TO citus;

--
-- TOC entry 5690 (class 0 OID 0)
-- Dependencies: 335
-- Name: images_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: citus
--

ALTER SEQUENCE public.images_file_id_seq OWNED BY public.images.file_id;


--
-- TOC entry 336 (class 1259 OID 19820)
-- Name: imagesdemo; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public.imagesdemo (
    file_id integer DEFAULT nextval('public.images_file_id_seq'::regclass) NOT NULL,
    title character varying(255),
    filename_short character varying(255),
    alt_url character varying(1024),
    description text,
    date_captured timestamp with time zone,
    location character varying(255),
    mime_type character varying(50),
    file_size bigint,
    width integer,
    height integer,
    md5 character varying(32),
    artist_id integer,
    device_id integer,
    uploaded_by integer
);


ALTER TABLE public.imagesdemo OWNER TO citus;

--
-- TOC entry 341 (class 1259 OID 19894)
-- Name: peopleinimage; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public.peopleinimage (
    file_id integer,
    person_name character varying(255),
    confidence_score numeric(2,2),
    msft_ai_person_guid uuid,
    msft_ai_age integer,
    msft_ai_gender character varying(20),
    msft_ai_face_rectangle_top integer,
    msft_ai_face_rectangle_left integer,
    msft_ai_face_rectangle_width integer,
    msft_ai_face_rectangle_height integer,
    msft_ai_bounding_box_x integer,
    msft_ai_bounding_box_y integer,
    msft_ai_bounding_box_w integer,
    msft_ai_bounding_box_h integer
);


ALTER TABLE public.peopleinimage OWNER TO citus;

--
-- TOC entry 337 (class 1259 OID 19829)
-- Name: uploaders; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public.uploaders (
    uploader_id integer NOT NULL,
    uploaded_by character varying(255)
);


ALTER TABLE public.uploaders OWNER TO citus;

--
-- TOC entry 338 (class 1259 OID 19832)
-- Name: uploaders_uploader_id_seq; Type: SEQUENCE; Schema: public; Owner: citus
--

CREATE SEQUENCE public.uploaders_uploader_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.uploaders_uploader_id_seq OWNER TO citus;

--
-- TOC entry 5691 (class 0 OID 0)
-- Dependencies: 338
-- Name: uploaders_uploader_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: citus
--

ALTER SEQUENCE public.uploaders_uploader_id_seq OWNED BY public.uploaders.uploader_id;


--
-- TOC entry 339 (class 1259 OID 19833)
-- Name: users; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    user_first_name character varying(255),
    user_last_name character varying(255),
    user_email character varying(255)
);


ALTER TABLE public.users OWNER TO citus;

--
-- TOC entry 340 (class 1259 OID 19836)
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: citus
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO citus;

--
-- TOC entry 5692 (class 0 OID 0)
-- Dependencies: 340
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: citus
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- TOC entry 342 (class 1259 OID 24593)
-- Name: withersarchive; Type: TABLE; Schema: public; Owner: citus
--

CREATE TABLE public.withersarchive (
    id integer,
    data character varying(255),
    mon character varying(255),
    yr integer,
    envelope_number integer,
    box_number integer,
    notes text,
    total_number_neg_strips integer,
    total_number_neg_images integer,
    original_location character varying(255),
    print_bw_8x10 integer,
    print_bw_5x7 integer,
    print_bw_4x5 integer,
    print_bw_other integer,
    print_color_8x10 integer,
    print_color_5x7 integer,
    print_color_4x5 integer,
    print_color_other integer,
    print_contact integer,
    print_test integer,
    print_envelope_number character varying(255),
    other integer,
    neg_image_bw_2x2 integer,
    neg_image_bw_4x5 integer,
    neg_image_bw_other integer,
    neg_image_color_2x2 integer,
    neg_image_color_4x5 integer,
    neg_image_color_other integer,
    negatives_envelope_number character varying(255),
    letter character varying(255),
    category character varying(255),
    box_description character varying(255),
    lifestyle character varying(255),
    box_description_abbrev character varying(255)
);


ALTER TABLE public.withersarchive OWNER TO citus;

--
-- TOC entry 5479 (class 2604 OID 24629)
-- Name: TestTable TestId; Type: DEFAULT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public."TestTable" ALTER COLUMN "TestId" SET DEFAULT nextval('public."TestTable_TestId_seq"'::regclass);


--
-- TOC entry 5472 (class 2604 OID 19837)
-- Name: artists artist_id; Type: DEFAULT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.artists ALTER COLUMN artist_id SET DEFAULT nextval('public.artists_artist_id_seq'::regclass);


--
-- TOC entry 5473 (class 2604 OID 19838)
-- Name: derivatives derivative_id; Type: DEFAULT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.derivatives ALTER COLUMN derivative_id SET DEFAULT nextval('public.derivatives_derivative_id_seq'::regclass);


--
-- TOC entry 5474 (class 2604 OID 19839)
-- Name: devices device_id; Type: DEFAULT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.devices ALTER COLUMN device_id SET DEFAULT nextval('public.devices_device_id_seq'::regclass);


--
-- TOC entry 5475 (class 2604 OID 19840)
-- Name: images file_id; Type: DEFAULT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.images ALTER COLUMN file_id SET DEFAULT nextval('public.images_file_id_seq'::regclass);


--
-- TOC entry 5477 (class 2604 OID 19841)
-- Name: uploaders uploader_id; Type: DEFAULT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.uploaders ALTER COLUMN uploader_id SET DEFAULT nextval('public.uploaders_uploader_id_seq'::regclass);


--
-- TOC entry 5478 (class 2604 OID 19842)
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- TOC entry 5481 (class 2606 OID 19844)
-- Name: ArtistImage ArtistImage_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public."ArtistImage"
    ADD CONSTRAINT "ArtistImage_pkey" PRIMARY KEY (artist_id, file_id);


--
-- TOC entry 5483 (class 2606 OID 19846)
-- Name: ArtistVideo ArtistVideo_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public."ArtistVideo"
    ADD CONSTRAINT "ArtistVideo_pkey" PRIMARY KEY (artist_id, video_id);


--
-- TOC entry 5507 (class 2606 OID 24631)
-- Name: TestTable TestTable_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public."TestTable"
    ADD CONSTRAINT "TestTable_pkey" PRIMARY KEY ("TestId");


--
-- TOC entry 5485 (class 2606 OID 19848)
-- Name: UserAssocType UserAssocType_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public."UserAssocType"
    ADD CONSTRAINT "UserAssocType_pkey" PRIMARY KEY (user_assoc_type_id);


--
-- TOC entry 5509 (class 2606 OID 24636)
-- Name: UserImage UserImage_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public."UserImage"
    ADD CONSTRAINT "UserImage_pkey" PRIMARY KEY (user_id, file_id, user_assoc_type_id);


--
-- TOC entry 5505 (class 2606 OID 24622)
-- Name: UserRoles UserRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "UserRoles_pkey" PRIMARY KEY (user_id, user_assoc_type_id);


--
-- TOC entry 5487 (class 2606 OID 19852)
-- Name: UserVideo UserVideo_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public."UserVideo"
    ADD CONSTRAINT "UserVideo_pkey" PRIMARY KEY (user_id, video_id, user_assoc_type_id);


--
-- TOC entry 5489 (class 2606 OID 19854)
-- Name: Videos Videos_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public."Videos"
    ADD CONSTRAINT "Videos_pkey" PRIMARY KEY (video_id);


--
-- TOC entry 5491 (class 2606 OID 19856)
-- Name: artists artists_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.artists
    ADD CONSTRAINT artists_pkey PRIMARY KEY (artist_id);


--
-- TOC entry 5493 (class 2606 OID 19858)
-- Name: derivatives derivatives_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.derivatives
    ADD CONSTRAINT derivatives_pkey PRIMARY KEY (derivative_id);


--
-- TOC entry 5495 (class 2606 OID 19860)
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (device_id);


--
-- TOC entry 5497 (class 2606 OID 19862)
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (file_id);


--
-- TOC entry 5499 (class 2606 OID 19864)
-- Name: imagesdemo imagesdemo_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.imagesdemo
    ADD CONSTRAINT imagesdemo_pkey PRIMARY KEY (file_id);


--
-- TOC entry 5501 (class 2606 OID 19866)
-- Name: uploaders uploaders_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.uploaders
    ADD CONSTRAINT uploaders_pkey PRIMARY KEY (uploader_id);


--
-- TOC entry 5503 (class 2606 OID 19868)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- TOC entry 5510 (class 2606 OID 19869)
-- Name: images images_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id);


--
-- TOC entry 5511 (class 2606 OID 19874)
-- Name: images images_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.uploaders(uploader_id);


--
-- TOC entry 5512 (class 2606 OID 19879)
-- Name: imagesdemo imagesdemo_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.imagesdemo
    ADD CONSTRAINT imagesdemo_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(artist_id);


--
-- TOC entry 5513 (class 2606 OID 19884)
-- Name: imagesdemo imagesdemo_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.imagesdemo
    ADD CONSTRAINT imagesdemo_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id);


--
-- TOC entry 5514 (class 2606 OID 19889)
-- Name: imagesdemo imagesdemo_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: citus
--

ALTER TABLE ONLY public.imagesdemo
    ADD CONSTRAINT imagesdemo_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.uploaders(uploader_id);


-- Completed on 2024-08-08 10:25:30

--
-- PostgreSQL database dump complete
--

