export class Constants {
    static readonly COLOR_MS_RED: string = '#F34F1C';
    static readonly COLOR_MS_GREEN: string = '#7FBC00';
    static readonly COLOR_MS_YELLOW: string = '#FFBA01';
    static readonly COLOR_MS_BLUE: string = '#01A6F0';
    static readonly COLOR_MS_GREY: string = '#747474';
}
