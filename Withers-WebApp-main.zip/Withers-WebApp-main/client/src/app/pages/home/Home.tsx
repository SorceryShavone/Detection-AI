import React from 'react';
import { SharedColors } from '@fluentui/theme';

const Home: React.FC = () => {
    return (<><h2>Home</h2>
    <div className="ms-Grid" dir="ltr">
    <div className="ms-Grid-row">
      <div  className="ms-Grid-col ms-sm6 ms-depth-8">A</div>
      <div  className="ms-Grid-col ms-sm6 ms-depth-8">B</div>
    </div>
  </div></>);
};

export default Home;
